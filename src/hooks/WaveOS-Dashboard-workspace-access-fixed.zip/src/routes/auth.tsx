import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";
import { WaveLogo } from "@/components/branding/wave-logo";

const POST_AUTH_NEXT_KEY = "waveos.postAuthNext";

export const Route = createFileRoute("/auth")({
  component: AuthPage,
  validateSearch: (s: Record<string, unknown>): { next?: string } =>
    typeof s.next === "string" ? { next: s.next } : {},
  head: () => ({
    meta: [
      { title: "Sign in — WaveOS" },
      { name: "description", content: "Sign in to your WaveOS workspace." },
      { property: "og:title", content: "Sign in — WaveOS" },
      { property: "og:description", content: "Sign in to your WaveOS workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
      { name: "robots", content: "noindex" },
    ],
  }),
});

// Only accept same-origin relative paths as post-signin destinations.
function safeNext(next: string | undefined): string {
  if (!next) return "/home";
  if (!next.startsWith("/") || next.startsWith("//")) return "/home";
  const pathname = next.split(/[?#]/, 1)[0];
  if (pathname === "/auth" || pathname === "/auth-callback") return "/home";
  return next;
}

function AuthPage() {
  const navigate = useNavigate();
  const search = Route.useSearch();
  const nextPath = safeNext(search.next);
  const [mode, setMode] = useState<"signin" | "reset">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  // Redirect signed-in users to the intended destination (or /home).
  useEffect(() => {
    let cancelled = false;
    const resolveNext = () => {
      const stashed = typeof window !== "undefined" ? sessionStorage.getItem(POST_AUTH_NEXT_KEY) : null;
      const target = safeNext(stashed ?? nextPath);
      if (stashed) sessionStorage.removeItem(POST_AUTH_NEXT_KEY);
      return target;
    };
    (async () => {
      const { data } = await supabase.auth.getSession();
      if (!cancelled && data.session) {
        const target = resolveNext();
        if (target !== "/home") window.location.replace(target);
        else navigate({ to: "/home", replace: true });
      }
    })();
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === "SIGNED_IN") {
        const target = resolveNext();
        if (target !== "/home") window.location.replace(target);
        else navigate({ to: "/home", replace: true });
      }
    });
    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, [navigate, nextPath]);

  async function handleEmailSignIn(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      toast.error(
        error.message === "Invalid login credentials" ? "That email or password isn't right." : error.message,
      );
      return;
    }
    toast.success("Welcome back.");
  }

  async function handleReset(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success("Check your email for a reset link.");
    setMode("signin");
  }

  async function handleGoogle() {
    setBusy(true);

    try {
      sessionStorage.setItem(POST_AUTH_NEXT_KEY, nextPath);

      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: `${window.location.origin}/auth-callback`,
        extraParams: {
          prompt: "select_account",
          ...(email ? { login_hint: email } : {}),
        },
      });

      if (result.error) {
        throw result.error;
      }

      if (!result.redirected) {
        if (result.tokens) {
          const { error } = await supabase.auth.setSession(result.tokens);
          if (error) throw error;
        }
        navigate({ to: "/home", replace: true });
      }
    } catch (error) {
      sessionStorage.removeItem(POST_AUTH_NEXT_KEY);
      setBusy(false);

      console.error("[Google sign-in error]", error);

      toast.error(error instanceof Error ? error.message : "Couldn't sign in with Google. Please try again.");
    }
  }

  return (
    <div className="relative flex min-h-screen items-center justify-center px-4 py-12">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(60%_50%_at_50%_0%,color-mix(in_oklab,var(--color-primary)_18%,transparent),transparent_70%)]" />
      <div className="relative w-full max-w-md">
        <div className="mb-8 flex justify-center">
          <Link to="/">
            <WaveLogo />
          </Link>
        </div>

        <div className="surface-card p-8">
          <div className="mb-6 text-center">
            <h1 className="text-2xl font-semibold tracking-tight text-foreground">
              {mode === "signin" ? "Sign in to WaveOS" : "Reset your password"}
            </h1>
            <p className="mt-2 text-sm text-muted-foreground">
              {mode === "signin"
                ? "Welcome back — sign in to your workspace."
                : "We'll email you a secure link to set a new password."}
            </p>
          </div>

          {mode === "signin" && (
            <>
              <button
                type="button"
                onClick={handleGoogle}
                disabled={busy}
                className="mb-4 flex w-full items-center justify-center gap-3 rounded-lg border border-border bg-surface/60 px-4 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-elevated disabled:opacity-60"
              >
                <GoogleIcon /> Continue with Google
              </button>
              <div className="mb-4 flex items-center gap-3 text-xs text-muted-foreground">
                <div className="h-px flex-1 bg-border" />
                or
                <div className="h-px flex-1 bg-border" />
              </div>
            </>
          )}

          <form onSubmit={mode === "signin" ? handleEmailSignIn : handleReset} className="space-y-4">
            <div>
              <label className="mb-1.5 block text-xs font-medium text-muted-foreground">Email</label>
              <input
                type="email"
                autoComplete="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-input bg-surface/60 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring/40"
                placeholder="you@company.com"
              />
            </div>

            {mode === "signin" && (
              <div>
                <div className="mb-1.5 flex items-center justify-between">
                  <label className="text-xs font-medium text-muted-foreground">Password</label>
                  <button
                    type="button"
                    onClick={() => setMode("reset")}
                    className="text-xs text-primary hover:text-primary-glow"
                  >
                    Forgot?
                  </button>
                </div>
                <input
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-lg border border-input bg-surface/60 px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:border-ring focus:outline-none focus:ring-2 focus:ring-ring/40"
                  placeholder="••••••••"
                />
              </div>
            )}

            <button
              type="submit"
              disabled={busy}
              className="flex w-full items-center justify-center gap-2 rounded-lg bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-[var(--shadow-glow)] transition-all hover:brightness-110 disabled:opacity-60"
            >
              {busy && <Loader2 className="h-4 w-4 animate-spin" />}
              {mode === "signin" ? "Sign in" : "Send reset link"}
            </button>

            {mode === "reset" && (
              <button
                type="button"
                onClick={() => setMode("signin")}
                className="w-full text-center text-xs text-muted-foreground hover:text-foreground"
              >
                ← Back to sign in
              </button>
            )}
          </form>

          <p className="mt-6 text-center text-xs text-muted-foreground">
            WaveOS is invite-only. Need access?{" "}
            <a
              href="mailto:dr3amwavemedia@outlook.com?subject=WaveOS%20access%20request"
              className="font-medium text-primary hover:text-primary-glow"
            >
              Contact Dream Wave Media
            </a>
          </p>
        </div>

        <p className="mt-6 text-center text-[11px] uppercase tracking-[0.2em] text-muted-foreground">
          A Dream Wave Media platform
        </p>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
      <path
        fill="#EA4335"
        d="M12 10.2v3.9h5.5c-.2 1.4-1.6 4-5.5 4-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.7 3.4 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12S6.7 21.6 12 21.6c6.9 0 9.5-4.8 9.5-7.3 0-.5-.1-.9-.1-1.3H12z"
      />
      <path
        fill="#34A853"
        d="M3.9 7.3l3.2 2.3c.9-2.1 3-3.7 5.4-3.7 1.5 0 2.7.5 3.6 1.4l2.7-2.6C17 3 14.7 2 12 2 8.1 2 4.7 4.2 3.1 7.4l.8-.1z"
      />
      <path
        fill="#FBBC05"
        d="M12 22c2.6 0 4.9-.9 6.5-2.4l-3-2.5c-.8.6-2 1-3.5 1-2.7 0-5-1.8-5.8-4.3l-3.1 2.4C4.7 19.7 8.1 22 12 22z"
      />
      <path
        fill="#4285F4"
        d="M21.5 12.3c0-.7-.1-1.3-.2-1.9H12v3.9h5.4c-.2 1.2-.9 2.1-1.9 2.8l3 2.4c1.8-1.6 2.9-4 2.9-7.2z"
      />
    </svg>
  );
}
